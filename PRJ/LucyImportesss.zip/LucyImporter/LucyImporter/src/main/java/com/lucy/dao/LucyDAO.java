package com.lucy.dao;

import com.lucy.model.LucyRow;
import com.lucy.util.DBConnection;

import java.sql.*;
import java.util.List;

/**
 * Thực hiện INSERT dữ liệu vào bảng LucyContents
 */
public class LucyDAO {

    private static final String INSERT_SQL =
        "INSERT INTO LucyContents (language_code, stage, level_name, sub_level, question_ai, answer) " +
        "VALUES (?, ?, ?, ?, ?, ?)";

    /**
     * Insert danh sách rows vào DB, dùng batch để nhanh hơn
     * @return số dòng đã insert thành công
     */
    public int insertBatch(List<LucyRow> rows) throws SQLException {
        if (rows == null || rows.isEmpty()) return 0;

        Connection conn = null;
        int total = 0;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {
                int batchCount = 0;

                for (LucyRow row : rows) {
                    ps.setNString(1, row.getLanguageCode());
                    ps.setNString(2, row.getStage());
                    ps.setNString(3, row.getLevelName());

                    // sub_level
                    if (row.getSubLevel() != null)
                        ps.setNString(4, row.getSubLevel());
                    else
                        ps.setNull(4, Types.NVARCHAR);

                    // question_ai
                    if (row.getQuestionAi() != null)
                        ps.setNString(5, row.getQuestionAi());
                    else
                        ps.setNull(5, Types.NVARCHAR);

                    // answer
                    if (row.getAnswer() != null)
                        ps.setNString(6, row.getAnswer());
                    else
                        ps.setNull(6, Types.NVARCHAR);

                    ps.addBatch();
                    batchCount++;

                    // Thực thi mỗi 100 dòng để tránh quá tải bộ nhớ
                    if (batchCount % 100 == 0) {
                        int[] counts = ps.executeBatch();
                        for (int c : counts) if (c > 0) total++;
                        System.out.printf("  ... đã insert %d dòng%n", total);
                    }
                }

                // Flush phần còn lại
                int[] counts = ps.executeBatch();
                for (int c : counts) if (c > 0) total++;
            }

            conn.commit();

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            throw e;
        } finally {
            DBConnection.close(conn);
        }

        return total;
    }

    /**
     * Xoá toàn bộ dữ liệu cũ trong LucyContents (gọi trước khi re-import)
     */
    public void clearTable() throws SQLException {
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement()) {
            int deleted = st.executeUpdate("DELETE FROM LucyContents");
            System.out.println("  Đã xoá " + deleted + " dòng cũ trong LucyContents");
        }
    }

    /**
     * Đếm số dòng hiện có trong LucyContents
     */
    public int countRows() throws SQLException {
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM LucyContents")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
